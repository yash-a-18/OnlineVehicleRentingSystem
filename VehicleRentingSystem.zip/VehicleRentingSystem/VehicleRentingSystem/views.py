#Created by Yash
from django.http import HttpResponse
from django.shortcuts import render
