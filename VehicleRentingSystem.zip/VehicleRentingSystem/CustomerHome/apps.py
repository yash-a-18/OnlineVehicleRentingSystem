from django.apps import AppConfig


class CustomerhomeConfig(AppConfig):
    name = 'CustomerHome'
